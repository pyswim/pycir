from pycir import *

ckt=Cir('OPAMP_OSC!')
ckt.add_nd_lst(['1','2','3'])
ng,n1,n2,n3=ckt.nds
n2.u0=5.0
r1=R(ckt,n1,ng,4000)
r2=R(ckt,n2,n1,1000)
r3=R(ckt,n2,n3,1000)
c=Cap(ckt,n3,ng,1e-6)
amp=OpAmp(ckt,n1,n3,n2)
ckt.add_cpns([r1,r2,r3,c,amp])
ckt.t_analyse(1e-5,1000)

plt.plot(ckt.ts,n3.u)
plt.plot(ckt.ts,c.i)
plt.legend(['u_c','i_c'])

plt.show()
