from pycir import *

ckt=Cir('Astable MultiVib')
ckt.add_nd_lst(['1','nb1','nb2','nc1','nc2'])
ng,n1,nb1,nb2,nc1,nc2=ckt.nds

def fon(t):
    if t<1e-6:
        return True
    else:
        return False

us=Usrc(ckt,n1,ng,lambda t:5)
sw=Swt(ckt,nb1,ng,fon)
rb1=R(ckt,n1,nb1,1000)
rb2=R(ckt,n1,nb2,1000)
rc1=R(ckt,n1,nc1,300)
rc2=R(ckt,n1,nc2,300)
c1=Cap(ckt,nc2,nb1,1e-7)
c2=Cap(ckt,nc1,nb2,1e-7)
q1=BJT_npn(ckt,nb1,nc1,ng)
q2=BJT_npn(ckt,nb2,nc2,ng)
'''this 2 capacitors must be added, otherwise the sudden flip will break down the solving algorithm'''
cbe1=Cap(ckt,nb1,ng,1e-7)
cbe2=Cap(ckt,nb2,ng,1e-7)


ckt.add_cpns([rb1,rb2,rc1,rc2,c1,c2,q1,q2,us,sw,cbe1,cbe2])
ckt.t_analyse(1e-7,10000)

fig1,ax1=plt.subplots()
fig2,ax2=plt.subplots()
ax1.plot(ckt.ts,nc1.u)
ax1.plot(ckt.ts,nc2.u)
ax2.plot(ckt.ts,q1.ib)
ax2.plot(ckt.ts,q2.ib)

ax1.legend(['out1','out2'])
ax2.legend(['Ib1','Ib2'])
plt.show()

  
