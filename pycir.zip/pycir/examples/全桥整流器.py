'''example 5: full bridge rectifier!!
'''
from pycir import *

ckt=Cir('FBR')
ckt.add_nd_lst(['1','2','3'])
ng,n1,n2,n3=ckt.nds
rload=R(ckt,n3,n1,430)
c=Cap(ckt,n3,n1,102e-6,0)
d1=Diode(ckt,n1,n2)
d2=Diode(ckt,n2,n3)
d3=Diode(ckt,ng,n3)
d4=Diode(ckt,n1,ng)
def f(t):
    return 5*sin(2*pi*50*t)
us=Usrc(ckt,n2,ng,f)
ckt.add_cpns([rload,c,d1,d2,d3,d4,us])
ckt.t_analyse(1e-5,10000)

plt.plot(ckt.ts,[i-j for i,j in zip(n3.u,n1.u)])
plt.legend(["voltage of load"])
plt.show()
