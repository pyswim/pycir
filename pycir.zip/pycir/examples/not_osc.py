from pycir import *

ckt=Cir('Not osc')
ckt.add_nd_lst([str(i) for i in range(1,7)])
ng,n1,n2,n3,n4,n5,n6=ckt.nds

def fon(t):
    
    if t<1e-4:
        return False
    else:
        return True

sw_kick=Swt(ckt,n1,n6,fon)
not1=Not(ckt,n1,n2)
not2=Not(ckt,n2,n3)
not3=Not(ckt,n5,n6)
r1=R(ckt,n3,n4,100)
r2=R(ckt,n4,n5,100)
c=Cap(ckt,n2,n4,10e-6)

ckt.add_cpns([sw_kick,not1,not2,not3,r1,r2,c])

#ckt.t_analyse(1e-5,10000)

ckt2=Cir('single not osc')
ckt2.add_nd_lst(['1','2','3'])
ng,n1,n2,n3=ckt2.nds

nt=Not(ckt2,n1,n2)
rc=R(ckt2,n2,n3,100)
rf=R(ckt2,n1,n3,1000)
c1=Cap(ckt2,n1,ng,10e-6)
c2=Cap(ckt2,n3,ng,10e-6)

ckt2.add_cpns([nt,rc,rf,c1,c2])
ckt2.t_analyse(1e-6,100000)
