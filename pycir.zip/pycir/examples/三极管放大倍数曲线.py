from pycir import *

ckt=Cir('BJT')
ckt.add_nd_lst(['b','c'])
ng,nb,nc=ckt.nds
us1=Usrc(ckt,nc,ng,lambda t:0.35*sin(2*pi*50*t))
us2=Usrc(ckt,nb,ng,lambda t:0.7)
q=BJT_npn(ckt,nb,nc,ng)

ckt.add_cpns([us1,us2,q])
ckt.t_analyse(1e-4,1000)

plt.plot(nc.u,[i/j for i,j in zip(q.ic,q.ib)])

plt.xlabel('collector voltage')
plt.ylabel('NRF')

plt.show()
