'''example 3: rc response to a function generator
'''
from pycir import *

ckt=Cir('hello3')
ckt.add_nd_lst(['1','2'])
ng,n1,n2=ckt.nds
r1=R(ckt,n1,n2,1000)
c1=Cap(ckt,n2,ng,1e-5,0)
def f(t):
    '''this function can be replaced by any other waves'''
    return 5*sin(2*pi*50*t)+5*sin(2*pi*10*t)

us=Usrc(ckt,n1,ng,f)
ckt.add_cpns([r1,c1,us])
ckt.t_analyse(1e-3,1000)
plt.plot(ckt.ts,n2.u)
plt.legend("cap")
plt.show()
