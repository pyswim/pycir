'''example 1: 2resistors in series
'''
from pycir import *
ckt=Cir('hello')
ckt.add_nd_lst(['1','2'])
ng,n1,n2=ckt.nds
r1=R(ckt,n1,n2,100)
r2=R(ckt,n2,ng,200)
us=Usrc(ckt,n1,ng,lambda t:6)
ckt.add_cpns([r1,r2,us])

ckt.t_analyse(1e-5,100)
plt.plot(ckt.ts,n1.u)
plt.plot(ckt.ts,n2.u)
plt.plot(ckt.ts,us.i)
plt.legend(['n1.u','n2.u','i'])
plt.show()

