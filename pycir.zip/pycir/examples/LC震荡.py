'''example 6: lc oscillator
'''
from pycir import *

ckt=Cir('LC')
ckt.add_nd_lst(['1'])
ng,n1=ckt.nds
c=Cap(ckt,ng,n1,1e-4,5)
l=Ind(ckt,n1,ng,0.01,0)
ckt.add_cpns([c,l])
ckt.t_analyse(1e-5,1000)
plt.plot(ckt.ts,n1.u)
plt.plot(ckt.ts,c.i)
plt.legend(['u','i'])

plt.show()
