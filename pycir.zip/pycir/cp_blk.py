from math import *
class OpAmp:
    def __init__(self,cir,np,nn,nout,uh=5,ul=-5,gain=1e5,on=True):
        '''np->n+  nn->n-
        the operation amplifier is modelized in an active way,
        which assumes its output in a specific state(H/L),
        when the inputs(n+,n-) change,
        the algo will detect whether to change the output IN THE NEXT TIME STEP,
        so you can assume that there is a delay between input and output.
        Only in this way can we (numerically) analyse the opamp circuit
        '''
        '''gain argument-> not available (to be fixed)'''
        self.cir=cir
        self.np=np
        self.nn=nn
        self.nout=nout
        self.uh=uh
        self.ul=ul
        self.gain=gain
        self.iout=[]
        self.iid=-1
        from pycir import Branch  #to tackle circular import, but will any pitfalls occure here?
        self.bout=Branch(self.nout,out=False)
        self.bout.i=self.current
        self.bout.jec_i=self.jcurrent
        self.on=on
        self.uout=uh
        if on:self.uout=uh
        else: self.uout=ul
        
        self.info='single'

    def on_init(self):
        self.iid,=self.cir.set_vars([0.])
        self.cir.set_ext_eq(self.ext_eq,self.j_ext_eq)
        
    def on_begin(self):
        self.iid,=self.cir.set_vars([0.])
        self.cir.set_ext_eq(self.ext_eq,self.j_ext_eq)

    def ext_eq(self):
        
        '''using sigmoid function to modelize'''
        '''
        ud=self.cir.get_var(self.np.uid)-self.cir.get_var(self.nn.uid)
        
        if ud>1e-3:
            return self.cir.get_var(self.nout.uid)-self.um
        elif ud<-1e-3:
            return self.cir.get_var(self.nout.uid)+self.um
            '''
        '''
        else:
            return self.cir.get_var(self.nout.uid)\
               -(self.um-2*self.um/(exp(1e6*ud)+1))
        '''

        return self.cir.get_var(self.nout.uid)-self.uout
        '''
        if self.on==True:
            return self.cir.get_var(self.nout.uid)-self.uh
        else:
            return self.cir.get_var(self.nout.uid)-self.ul
        '''
        
        '''
        uo=self.cir.get_var(self.nout.uid)
        ua=self.cir.get_var(self.np.uid)
        ub=self.cir.get_var(self.nn.uid)
        return uo-self.um*self.sig(1e4*(ua-ub))+self.um/2'''
    
    def j_ext_eq(self):
        '''
        ud=self.cir.get_var(self.np.uid)-self.cir.get_var(self.nn.uid)
        
        if -1e-2<ud<1e-2:
            tmp=-1e4*self.um*self.dsig(1e4*ud)
            return (self.nout.uid,1),(self.np.uid,tmp),(self.nn.uid,-tmp)
        
        else:
            return (self.nout.uid,1),#,(self.np.uid,-1e-6),(self.nn.uid,1e-6)
            '''
        return (self.nout.uid,1),
    
    def update(self):
        self.iout.append(self.cir.get_res(self.iid))
        ud=self.cir.get_res(self.np.uid)-self.cir.get_res(self.nn.uid)
        '''detect output state in the next time step'''
        '''
        uexp=self.gain*ud
        if uexp<self.ul:
            self.uout=self.ul
        elif uexp>self.uh:
            self.uout=self.uh
        else:
            self.uout=uexp
        '''
        
        if ud<0:
            self.on=False
            self.uout=self.ul
        else:
            self.on=True
            self.uout=self.uh
                
        
    def current(self):
        return self.cir.get_var(self.iid)
    def jcurrent(self):
        return (self.iid,1),
    def get_branch(self):
        return self.bout,

class Acas:
    '''current control current source'''
    def __init__(self,cir,n1,n2,cbr,f,df):
        '''current dir: n2->n1
        cbr->controlling branch, out=False->+
        I_21=f(Ibr)
        NOTICE: the res of output current is not calculated! (no i attribute)'''
        self.cir=cir
        self.n1=n1
        self.n2=n2
        self.cbr=cbr
        self.f=f
        self.df=df
        from pycir import Branch
        self.br1=Branch(self.n1,out=False)
        self.br2=Branch(self.n2,out=True)
        self.br1.i,self.br1.jec_i=self.current,self.jcurrent
        self.br2.i,self.br2.jec_i=self.current,self.jcurrent
        self.info='single'
        
    def on_init(self):
        pass
    def on_begin(self):
        pass
    def update(self):
        '''
        if self.cbr.out==False:
            self.i.append(self.f(self.rs_i()))
        else:
            self.i.append(self.f(self.rs_i()))
        '''
        pass
    def current(self):
        if self.cbr.out==False:
            return self.f(self.cbr.i())
        else :
            return self.f(-self.cbr.i())
    def jcurrent(self):
        jic=self.cbr.jec_i()
        if self.cbr.out==False:
            ic=self.cbr.i()
            d=self.df(ic)
            return [(i,d*j)for i,j in jic]
        else:
            ic=-self.cbr.i()
            d=self.df(ic)
            return [(i,d*j)for i,j in jic]
    def get_branch(self):
        return self.br1,self.br2


class Trnsfrmr2:
    '''2-tapped transformer'''
    def __init__(self,cir,nin1,nout1,nin2,nout2,l1,l2,m,i10=1e-3,i20=1e-3):
        '''nin1,nin2 -> same polar'''
        self.cir=cir
        self.info='single'
        self.nin1=nin1
        self.nout1=nout1
        self.nin2=nin2
        self.nout2=nout2
        self.i10=i10
        self.i20=i20
        self.l1=l1
        self.l2=l2
        self.m=m
        self.i1=[]
        self.i2=[]
        
        from pycir import Branch
        self.brin1=Branch(nin1,out=True)
        self.brout1=Branch(nout1,out=False)
        self.brin2=Branch(nin2,out=True)
        self.brout2=Branch(nout2,out=False)
        
        self.brin1.i,self.brout1.i=self.current1,self.current1
        self.brin1.jec_i,self.brout1.jec_i=self.jcurrent1,self.jcurrent1
        self.brin2.i,self.brout2.i=self.current2,self.current2
        self.brin2.jec_i,self.brout2.jec_i=self.jcurrent2,self.jcurrent2
    
    def on_init(self):
        self.i1=[]
        self.i2=[]
    def on_begin(self):
        pass
    def get_branch(self):
        return self.brin1,self.brout1,self.brin2,self.brout2

    def current1(self):
        if self.cir.proc=='init_analysing':
            return self.i10
        elif self.cir.proc=='t_analysing':
            u1=self.cir.get_var(self.nin1.uid)-self.cir.get_var(self.nout1.uid)
            u2=self.cir.get_var(self.nin2.uid)-self.cir.get_var(self.nout2.uid)
            di1=(u1*self.l2-u2*self.m)/(self.l1*self.l2-self.m**2)*self.cir.dt
            return self.i1[-1]+di1
    

    def jcurrent1(self):
        if self.cir.proc=='init_analysing':
            return tuple()
        elif self.cir.proc=='t_analysing':
            tmp1=self.l2/(self.l1*self.l2-self.m**2)*self.cir.dt
            tmp2=-self.m/(self.l1*self.l2-self.m**2)*self.cir.dt
            return (self.nin1.uid,tmp1),(self.nout1.uid,-tmp1),(self.nin2.uid,tmp2),(self.nout2.uid,-tmp2)
        
        
    def current2(self):
        if self.cir.proc=='init_analysing':
            return self.i20
        elif self.cir.proc=='t_analysing':
            u1=self.cir.get_var(self.nin1.uid)-self.cir.get_var(self.nout1.uid)
            u2=self.cir.get_var(self.nin2.uid)-self.cir.get_var(self.nout2.uid)
            di2=(u2*self.l1-u1*self.m)/(self.l1*self.l2-self.m**2)*self.cir.dt
            return self.i2[-1]+di2
    def jcurrent2(self):
        if self.cir.proc=='init_analysing':
            return tuple()
        elif self.cir.proc=='t_analysing':
            tmp2=self.l1/(self.l1*self.l2-self.m**2)*self.cir.dt
            tmp1=-self.m/(self.l1*self.l2-self.m**2)*self.cir.dt
            return (self.nin1.uid,tmp1),(self.nout1.uid,-tmp1),(self.nin2.uid,tmp2),(self.nout2.uid,-tmp2)

    def update(self):
        if self.cir.proc=='done_init':
            self.i1.append(self.i10)
            self.i2.append(self.i20)
        elif self.cir.proc=='done_tstep':
            u1=self.cir.get_res(self.nin1.uid)-self.cir.get_res(self.nout1.uid)
            u2=self.cir.get_res(self.nin2.uid)-self.cir.get_res(self.nout2.uid)
            self.i1.append((u1*self.l2-u2*self.m)/(self.l1*self.l2-self.m**2)*self.cir.dt+self.i1[-1])
            self.i2.append((u2*self.l1-u1*self.m)/(self.l1*self.l2-self.m**2)*self.cir.dt+self.i2[-1])
    
    
class Vcvs:
    '''voltage control voltage source'''
    def __init__(self,cir,nin1,nin2,nout1,nout2,f,df):
        '''in1->+ int2->-
        out1->+ out2->-
        uout=f(uin)
        df->deriv of f'''
        self.cir=cir
        self.nin1=nin1
        self.nin2=nin2
        self.nout1=nout1
        self.nout2=nout2
        self.f=f
        self.df=df
        self.iid=-1
        self.iout=[]
        from pycir import Branch
        self.br1=Branch(nout1,out=False)
        self.br2=Branch(nout2,out=True)
        self.br1.i,self.br1.jec_i=self.current,self.jcurrent
        self.br2.i,self.br2.jec_i=self.current,self.jcurrent
        self.info='single'
    def on_init(self):
        self.iid,=self.cir.set_vars([0.])
        self.cir.set_ext_eq(self.ext_eq,self.j_ext_eq)
    def on_begin(self):
        self.iid,=self.cir.set_vars([0.])
        self.cir.set_ext_eq(self.ext_eq,self.j_ext_eq)
    def update(self):
        self.iout.append(self.cir.get_res(self.iid))
        
    def ext_eq(self):
        uin=self.cir.get_var(self.nin1.uid)-self.cir.get_var(self.nin2.uid)
        return self.cir.get_var(self.nout1.uid)-self.cir.get_var(self.nout2.uid)-self.f(uin)
    def j_ext_eq(self):
        uin=self.cir.get_var(self.nin1.uid)-self.cir.get_var(self.nin2.uid)
        return (self.nout1.uid,1),(self.nout2.uid,-1),(self.nin1.uid,-self.df(uin)),(self.nin2.uid,self.df(uin))
    def current(self):
        return self.cir.get_var(self.iid)
    def jcurrent(self):
        return (self.iid,1),
    def get_branch(self):
        return self.br1,self.br2,

    
