from pycir import *

ckt=Cir()
ckt.add_nd_lst(['1','2'])
ng,n1,n2=ckt.nds

def f(x):
    return 5*(1-1/(1+exp(x)))
def df(x):
    return 5*(exp(x)/(1+exp(x))**2)

amp=Vcvs(ckt,n1,ng,n2,ng,f,df)
r=R(ckt,n2,n1,1e3)
l=Ind(ckt,n1,ng,20e-3,0)
c=Cap(ckt,n1,ng,1e-6,0.1)

ckt.add_cpns([amp,r,l,c])

ckt.t_analyse(1e-6,100000)

def mes_duty(ts,us,thr=0):
    '''a very simple method to measure duty cycle'''
    cnt=0
    for i in range(len(us)-1):
        if (us[i]-thr==0 or (us[i]-thr)*(us[i+1]-thr)<0):
            cnt+=1
    return 2*(ts[-1]-ts[0])/cnt

f=1/mes_duty(ckt.ts,n1.u)

print('expect freq:',1/(2*pi*sqrt(l.l*c.c)))
print('measured freq:',f)


