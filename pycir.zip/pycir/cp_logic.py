from math import *

class Logic1:
    def __init__(self,cir,nout,uh=5,ul=0,slope=1e5):
        '''a base class for logic gates with 1 output
            self.judge should be rewritten to change self.on
            self.slope->switching rate (v/s)'''
        self.cir=cir
        self.nout=nout
        self.uh=uh
        self.ul=ul
        self.uout=ul
        
        self.slope=slope
        self.iout=[]
        self.i_iout=-1
        from pycir import Branch
        self.bout=Branch(self.nout,out=False)
        self.bout.i=self.current
        self.bout.jec_i=self.jcurrent
        self.on=False
        self.info='single'
        
    def on_init(self):
        self.iout=[]
        self.i_iout,=self.cir.set_vars([0.])
        self.cir.set_ext_eq(self.feq,self.jfeq)
    def feq(self):
        if self.on:
            self.uout+=self.slope*self.cir.dt
            if self.uout>self.uh:self.uout=self.uh
            return self.cir.get_var(self.nout.uid)-self.uout
        else:
            self.uout-=self.slope*self.cir.dt
            if self.uout<self.ul:self.uout=self.ul
            return self.cir.get_var(self.nout.uid)-self.uout
    def jfeq(self):
        return (self.nout.uid,1),
    def current(self):
        return self.cir.get_var(self.i_iout)
    def jcurrent(self):
        return (self.i_iout,1),
    def on_begin(self):
        self.i_iout,=self.cir.set_vars([0.])
        self.cir.set_ext_eq(self.feq,self.jfeq)
    def update(self):
        self.iout.append(self.cir.get_res(self.i_iout))
        self.judge()
    def judge(self):
        pass
    def get_branch(self):
        return self.bout,
        
class Not(Logic1):
    def __init__(self,cir,nin,nout,uth=1,uh=5,ul=0,slope=1e5):
        super().__init__(cir,nout,uh,ul,slope)
        self.nin=nin
        self.uth=uth
    def judge(self):
        uin=self.cir.get_res(self.nin.uid)
        if uin>self.uth:
            self.on=False
        else:
            self.on=True


'''
    old version:
        self.cir=cir
        self.nin=nin
        self.nout=nout
        self.uh=uh
        self.ul=ul
        self.uth=uth
        self.uout=ul
        self.slope=1e5
        self.iout=[]
        self.i_iout=-1
        from pycir import Branch
        self.bout=Branch(self.nout,out=False)
        self.bout.i=self.current
        self.bout.jec_i=self.jcurrent
        self.on=False
        self.info='single'

    def on_init(self):
        self.iout=[]
        self.i_iout,=self.cir.set_vars([0.])
        self.cir.set_ext_eq(self.feq,self.jfeq)
    def feq(self):
        if self.on:
            self.uout+=self.slope*self.cir.dt
            if self.uout>self.uh:self.uout=self.uh
            return self.cir.get_var(self.nout.uid)-self.uout
        else:
            self.uout-=self.slope*self.cir.dt
            if self.uout<self.ul:self.uout=self.ul
            return self.cir.get_var(self.nout.uid)-self.uout
    def jfeq(self):
        return (self.nout.uid,1),
    def current(self):
        return self.cir.get_var(self.i_iout)
    def jcurrent(self):
        return (self.i_iout,1),
    def on_begin(self):
        self.i_iout,=self.cir.set_vars([0.])
        self.cir.set_ext_eq(self.feq,self.jfeq)
    def update(self):
        self.iout.append(self.cir.get_res(self.i_iout))
        if self.on==True:
            if self.cir.get_res(self.nin.uid)>self.uth:
                self.on=False
        else:
            if self.cir.get_res(self.nin.uid)<self.uth:
                self.on=True
    def get_branch(self):
        return self.bout,'''
'''
from pycir import *
ckt=Cir()
ckt.add_nd_lst(['1','2'])
ng,n1,n2=ckt.nds
us=Usrc(ckt,n1,ng,lambda t:2.5*sin(2*pi*50*t)+2.5)
nt=Not(ckt,n1,n2)
r=R(ckt,n2,ng,10)

ckt.add_cpns([us,nt,r])
ckt.t_analyse(1e-4,10000)
'''

class And(Logic1):
    def __init__(self,cir,nin1,nin2,nout,uth=1,uh=5,ul=0,slope=1e5):
        super().__init__(cir,nout,uh,ul,slope)
        self.nin1=nin1
        self.nin2=nin2
        self.uth=uth

    def judge(self):
        u1=self.cir.get_res(self.nin1.uid)
        u2=self.cir.get_res(self.nin2.uid)
        if u1>self.uth and u2>self.uth:
            self.on=True
        else:
            self.on=False

class And(Logic1):
    def __init__(self,cir,nin1,nin2,nout,uth=1,uh=5,ul=0,slope=1e5):
        super().__init__(cir,nout,uh,ul,slope)
        self.nin1=nin1
        self.nin2=nin2
        self.uth=uth

    def judge(self):
        u1=self.cir.get_res(self.nin1.uid)
        u2=self.cir.get_res(self.nin2.uid)
        if u1>self.uth and u2>self.uth:
            self.on=True
        else:
            self.on=False

class Or(Logic1):
    def __init__(self,cir,nin1,nin2,nout,uth=1,uh=5,ul=0,slope=1e5):
        super().__init__(cir,nout,uh,ul,slope)
        self.nin1=nin1
        self.nin2=nin2
        self.uth=uth

    def judge(self):
        u1=self.cir.get_res(self.nin1.uid)
        u2=self.cir.get_res(self.nin2.uid)
        if u1>self.uth or u2>self.uth:
            self.on=True
        else:
            self.on=False

    
class Xor(Logic1):
    def __init__(self,cir,nin1,nin2,nout,u_th=1,uh=5,ul=0,slope=1e5):
        super().init(cir,nout,uh,ul,slope)
        self.nin1=nin1
        self.nin2=nin2
        self.uth=uth

    def judge(self):
        u1=self.cir.get_res(self.nin1.uid)
        u2=self.cir.get_res(self.nin2.uid)
        if (u1>self.uth and u2>self.uth) or (u1<self.uth and u2<self.uth):
            self.on=False
        else:
            self.on=True

    
