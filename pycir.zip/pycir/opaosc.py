from pycir import *

ckt=Cir()
ckt.add_nd_lst(['1','2'])

def s(x):
    return 1/(1+exp(-x))
def ds(x):
    return s(x)*(1-s(x))
def fctl(u):
    return 10*s(u)-5
'''
    if 10*u>5:
        return 5
    elif 10*u<-5:
        return -5
    else :
        return 10*u
        '''
def dfctl(u):
    return 10*ds(u)

    '''
    if -5<10*u<5:
        return 10
    else:
        return 0'''
    
ng,n1,n2=ckt.nds

rc=R(ckt,n1,ng,100)
c=Cap(ckt,n2,n1,1e-6,0.001)
amp=Vcvs(ckt,n1,ng,n2,ng,fctl,dfctl)
ckt.add_cpns([rc,c,amp])
ckt.t_analyse(1e-3,10000)

