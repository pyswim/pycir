from pycir import *
import random as rnd

ckt=Cir('colpitt')

ckt.add_nd_lst(['nb','nc','n1','n2','n3','n4'])

ng,nb,nc,n1,n2,n3,n4=ckt.nds

def fn(t):
    if t<10-5:
        return 0.1*rnd.random()
    else:
        return 0
us=Usrc(ckt,n1,ng,lambda t:5)
#noise=Usrc(ckt,n4,ng,fn)
rb=R(ckt,n2,nb,1000)
rf=R(ckt,nc,n3,1000)
rc=R(ckt,n1,nc,1000)
#rn=R(ckt,n4,n2,100e3)
c1=Cap(ckt,n2,ng,10e-6)
c2=Cap(ckt,n3,ng,10e-6)
l=Ind(ckt,n2,n4,40e-3,0)
q=BJT_npn(ckt,nb,nc,ng)
rl=R(ckt,n4,n3,10)

ckt.add_cpns([us,rb,rf,rc,c1,c2,l,q,rl])

ckt.t_analyse(1e-5,10000)
