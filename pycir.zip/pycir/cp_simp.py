import scipy as sp
import numpy as np
import scipy.optimize as opt
import matplotlib.pyplot as plt
from math import *


class cpn_2p:
    '''base class for components with 2 pins'''
    def __init__(self,cir,n1,n2):
        '''ref dir: n1->n2'''
        self.cir=cir
        self.n1=n1
        self.n2=n2
        self.i=[]
        from pycir import Branch
        self.br1=Branch(self.n1,out=True)
        self.br2=Branch(self.n2,out=False)
        self.br1.i=self.current
        self.br1.jec_i=self.jcurrent
        self.br2.i=self.current
        self.br2.jec_i=self.jcurrent
        self.info='single' #single component with no buildin subcomponents
    def current(self):
        pass
    def jcurrent(self):
        pass
    def on_init(self):
        self.i=[]
    def on_begin(self):
        pass
    def get_branch(self):
        return self.br1,self.br2
    def update(self):
        pass


class R(cpn_2p):
    def __init__(self,cir,n1,n2,r):
        super().__init__(cir,n1,n2)
        self.r=r

    def current(self):
        u1=self.cir.get_var(self.n1.uid)
        u2=self.cir.get_var(self.n2.uid)
        return (u1-u2)/self.r
    def jcurrent(self):
        return (self.n1.uid,1/self.r),(self.n2.uid,-1/self.r)

    def update(self):
        u1=self.cir.get_res(self.n1.uid)
        u2=self.cir.get_res(self.n2.uid)
        self.i.append((u1-u2)/self.r)

class Cap(cpn_2p):
    def __init__(self,cir,n1,n2,c,u0=0):
        super().__init__(cir,n1,n2)
        self.c=c
        self.u0=u0
        self.iid=-1

    def on_init(self):
        self.i=[]
        self.iid,=self.cir.set_vars([0.])
        self.cir.set_ext_eq(self.ext_eq,self.j_ext_eq)
    def ext_eq(self):
        u1=self.cir.get_var(self.n1.uid)
        u2=self.cir.get_var(self.n2.uid)
        return u1-u2-self.u0
    def j_ext_eq(self):
        return (self.n1.uid,1),(self.n2.uid,-1)
    def current(self):
        if self.cir.proc=='init_analysing':
            return self.cir.get_var(self.iid)
        elif self.cir.proc=='t_analysing':
            '''using back euler method'''
            du1=self.cir.get_var(self.n1.uid)-self.n1.u[-1]
            du2=self.cir.get_var(self.n2.uid)-self.n2.u[-1]
            return self.c*(du1-du2)/self.cir.dt
    
    def jcurrent(self):
        if self.cir.proc=='init_analysing':
            return (self.iid,1),
        elif self.cir.proc=='t_analysing':
            return (self.n1.uid,self.c/self.cir.dt),(self.n2.uid,-self.c/self.cir.dt)
        
    def update(self):
        if self.cir.proc=='done_init':
            self.i.append(self.cir.get_res(self.iid))
            self.iid=-1
        elif self.cir.proc=='done_tstep':
            '''note: nodes are updated earlier than components'''
            du1=self.n1.u[-1]-self.n1.u[-2]
            du2=self.n2.u[-1]-self.n2.u[-2]
            self.i.append(self.c*(du1-du2)/self.cir.dt)

class Ind(cpn_2p):
    def __init__(self,cir,n1,n2,l,i0):
        super().__init__(cir,n1,n2)
        self.n1=n1
        self.n2=n2
        self.l=l
        self.i0=i0
    def current(self):
        if self.cir.proc=='init_analysing':
            return self.i0
        elif self.cir.proc=='t_analysing':
            u1=self.cir.get_var(self.n1.uid)
            u2=self.cir.get_var(self.n2.uid)
            return (u1-u2)*self.cir.dt/self.l+self.i[-1]
    def jcurrent(self):
        if self.cir.proc=='init_analysing':
            return tuple()
        elif self.cir.proc=='t_analysing':
            tmp=self.cir.dt/self.l
            return (self.n1.uid,tmp),(self.n2.uid,-tmp)
    def update(self):
        if self.cir.proc=='done_init':
            self.i.append(self.i0)
        elif self.cir.proc=='done_tstep':
            u1=self.cir.get_res(self.n1.uid)
            u2=self.cir.get_res(self.n2.uid)
            self.i.append((u1-u2)*self.cir.dt/self.l+self.i[-1])

class Diode(cpn_2p):
    def __init__(self,cir,n1,n2):
        super().__init__(cir,n1,n2)
        self.isat=1e-11
        self.ut=26e-3
    def current(self):
        u1=self.cir.get_var(self.n1.uid)
        u2=self.cir.get_var(self.n2.uid)
        try:
            tmp=self.isat*(exp((u1-u2)/self.ut)-1)
        except OverflowError:
            tmp=1e6
        if tmp>1e6:
            return 1e6
        else:
            return tmp 
    def jcurrent(self):
        u1=self.cir.get_var(self.n1.uid)
        u2=self.cir.get_var(self.n2.uid)
        try:
            tmp=self.isat*exp((u1-u2)/self.ut)/self.ut
        except OverflowError:
            tmp=1e6
        if tmp>1e6:
            tmp=1e6
        return (self.n1.uid,tmp),(self.n2.uid,-tmp)
    def update(self):
        u1=self.cir.get_res(self.n1.uid)
        u2=self.cir.get_res(self.n2.uid)
        self.i.append(self.isat*(exp((u1-u2)/self.ut)-1))

class Usrc(cpn_2p):
    def __init__(self,cir,n1,n2,fu):
        '''fu(t):function of voltage'''
        super().__init__(cir,n1,n2)
        self.fu=fu
        self.iid=-1
        self.us=self.fu(0)
    def on_init(self):
        self.i=[]
        self.iid,=self.cir.set_vars([0.])
        self.cir.set_ext_eq(self.ex_eq,self.j_ex_eq)

    def on_begin(self):
        self.iid,=self.cir.set_vars([0.])
        self.cir.set_ext_eq(self.ex_eq,self.j_ex_eq)
    def ex_eq(self):
        u1=self.cir.get_var(self.n1.uid)
        u2=self.cir.get_var(self.n2.uid)
        return u1-u2-self.us
    def j_ex_eq(self):
        return (self.n1.uid,1),(self.n2.uid,-1)

    def current(self):
        return self.cir.get_var(self.iid)
    
    def jcurrent(self):
        return (self.iid,1),
    
    def update(self):
        self.us=self.fu(self.cir.ts[-1])
        self.i.append(self.cir.get_res(self.iid))

class Acv_2p:
    '''2-pin current control voltage component'''
    def __init__(self,cir,n1,n2,f,df):
        self.cir=cir
        self.n1=n1
        self.n2=n2
        self.f=f
        self.df=df
        self.i=[]
        self.iid=-1

        from pycir import Branch
        self.br1=Branch(self.n1,out=True)
        self.br2=Branch(self.n2,out=False)
        self.br1.i=self.current
        self.br1.jec_i=self.jcurrent
        self.br2.i=self.current
        self.br2.jec_i=self.jcurrent
        self.info='single'

    def on_init(self):
        self.i=[]
        self.iid,=self.cir.set_vars([0.])
        self.cir.set_ext_eq(self.ex_eq,self.j_ex_eq)

    def on_begin(self):
        self.iid,=self.cir.set_vars([0.])
        self.cir.set_ext_eq(self.ex_eq,self.j_ex_eq)

    def current(self):
        return self.cir.get_var(self.iid)
    
    def jcurrent(self):
        return (self.iid,1),

    def ex_eq(self):
        return self.f(self.cir.get_var(self.iid))-(self.cir.get_var(self.n1.uid)-self.cir.get_var(self.n2.uid))

    def j_ex_eq(self):
        return (self.iid,self.df(self.cir.get_var(self.iid))),(self.n1.uid,-1),(self.n2.uid,1)    

    def get_branch(self):
        return self.br1,self.br2

    def update(self):
        self.i.append(self.cir.get_res(self.iid))

class Swt(cpn_2p):
    def __init__(self,cir,n1,n2,fon):
        '''fon(t)->True to turn on,False to turn off'''
        super().__init__(cir,n1,n2)
        self.fon=fon
        self.iid=-1
        self.on=fon(0)
        
    def on_init(self):
        self.i=[]
        self.iid,=self.cir.set_vars([0.])
        self.cir.set_ext_eq(self.eq,self.jeq)

    def eq(self):
        if self.on==True:
            return self.cir.get_var(self.n1.uid)-self.cir.get_var(self.n2.uid)
        else:
            return self.cir.get_var(self.iid)
    def jeq(self):
        if self.on==True:
            return (self.n1.uid,1),(self.n2.uid,-1)
        else:
            return (self.iid,1),
    
    def on_begin(self):
        self.iid,=self.cir.set_vars([0.])
        self.cir.set_ext_eq(self.eq,self.jeq)
    def update(self):
        self.on=self.fon(self.cir.ts[-1])
        self.i.append(self.cir.get_res(self.iid))
        
    def get_branch(self):
        return self.br1,self.br2

    def current(self):
        if self.on==True:
            return self.cir.get_var(self.iid)
        else:
            return 0
        
    def jcurrent(self):
        if self.on==True:
            return (self.iid,1),
        else:
            return []
