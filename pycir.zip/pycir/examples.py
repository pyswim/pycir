from pycir import *
'''example 1: 2resistors in series

ckt=Cir('hello')
ckt.add_nd_lst(['1','2'])
ng,n1,n2=ckt.nds
r1=R(n1,n2,100)
r2=R(n2,ng,200)
us=Usrc(ckt,ckt.nds[1],ckt.nds[0],5)
ckt.add_cpns([r1,r2,us])
ckt.init_analyse()
ckt.t_analyse(1e-5,100)
plt.plot(ckt.ts,n1.u)
plt.plot(ckt.ts,n2.u)
plt.plot(ckt.ts,us.i)
plt.legend(['n1.u','n2.u','i'])
plt.show()
'''

'''example 2: rc in series
ckt=Cir('hello2')
ckt.add_nd_lst(['1','2'])
ng,n1,n2=ckt.nds
r1=R(ckt,n1,n2,1000)
c1=Cap(ckt,n2,ng,1e-4,0)
us=Usrc(ckt,n1,ng,5)
ckt.add_cpns([r1,c1,us])
ckt.t_analyse(1e-3,10000)
plt.plot(ckt.ts,n2.u)
plt.show()
'''

'''example 3: rc response to a function generator

ckt=Cir('hello3')
ckt.add_nd_lst(['1','2'])
ng,n1,n2=ckt.nds
r1=R(ckt,n1,n2,1000)
c1=Cap(ckt,n2,ng,1e-5,0)
def f(t):
    if int(t/0.02)%2==0:
        return 0
    else:
        return 5
    #return 5*sin(2*pi*50*t)+5*sin(2*pi*10*t)
us=FuncGen(ckt,n1,ng,f)
ckt.add_cpns([r1,c1,us])
ckt.t_analyse(1e-3,1000)
plt.plot(ckt.ts,n2.u)
plt.show()
'''
'''example 4: half wave rectifier
ckt=Cir('hello4')
ckt.add_nd_lst(['1','2'])
ng,n1,n2=ckt.nds
r1=R(ckt,n1,n2,1000)
d1=Diode(ckt,n2,ng)
def f(t):
    return 5*sin(2*pi*50*t)
us=FuncGen(ckt,n1,ng,f)
ckt.add_cpns([r1,d1,us])
ckt.t_analyse(1e-5,10000)
plt.plot(ckt.ts,n2.u)
plt.show()
#plt.plot(n2.u,d1.i)  show u-v curve
'''
'''example 5: fuuulll bridge rectifier!!
ckt=Cir('FBR')
ckt.add_nd_lst(['1','2','3','4'])
ng,n1,n2,n3,n4=ckt.nds
rload=R(ckt,n3,n1,1000)
rc=R(ckt,n4,n1,10)
c=Cap(ckt,n3,n4,1e-4,0)
d1=Diode(ckt,n1,n2)
d2=Diode(ckt,n2,n3)
d3=Diode(ckt,ng,n3)
d4=Diode(ckt,n1,ng)
def f(t):
    return 5*sin(2*pi*50*t)
us=Usrc(ckt,n2,ng,f)
ckt.add_cpns([rload,rc,c,d1,d2,d3,d4,us])
ckt.t_analyse(1e-5,10000)

plt.plot(ckt.ts,[i-j for i,j in zip(n3.u,n1.u)])

#plt.plot([i-j for i,j in zip(n3.u,n4.u)],c.i)
'''
'''example 6: lc oscillator
ckt=Cir('LC')
ckt.add_nd_lst(['1'])
ng,n1=ckt.nds
c=Cap(ckt,ng,n1,1e-4,5)
l=Ind(ckt,n1,ng,0.01,0)
ckt.add_cpns([c,l])
ckt.t_analyse(1e-5,1000)
'''
'''
ckt=Cir('OPAMP')
ckt.add_nd_lst(['1','2'])
ng,n1,n2=ckt.nds
n2.u0=0.
r=R(ckt,n2,ng,1000)
amp=OpAmp(ckt,n1,ng,n2)
def f(t):
    if int(t/0.001)%2==0:
        return 5
    else:
        return -5
us=Usrc(ckt,n1,ng,lambda t:5*sin(2*pi*100*t))
ckt.add_cpns([r,amp,us])
ckt.t_analyse(1e-5,10000)
'''
'''
ckt=Cir('OPAMP_OSC!')
ckt.add_nd_lst(['1','2','3'])
ng,n1,n2,n3=ckt.nds
n2.u0=5.0
r1=R(ckt,n1,ng,4000)
r2=R(ckt,n2,n1,1000)
r3=R(ckt,n2,n3,1000)
c=Cap(ckt,n3,ng,1e-6)
amp=OpAmp(ckt,n1,n3,n2)
ckt.add_cpns([r1,r2,r3,c,amp])
ckt.t_analyse(1e-5,1000)
'''
'''
ckt=Cir('BJT')
ckt.add_nd_lst(['b','c'])
ng,nb,nc=ckt.nds
us1=Usrc(ckt,nc,ng,lambda t:0.35*sin(2*pi*50*t))
us2=Usrc(ckt,nb,ng,lambda t:0.7)
q=BJT_npn(ckt,nb,nc,ng)

ckt.add_cpns([us1,us2,q])
ckt.t_analyse(1e-4,1000)
'''

ckt=Cir('Bistable MultiVib')
ckt.add_nd_lst(['1','nb1','nb2','nc1','nc2'])
ng,n1,nb1,nb2,nc1,nc2=ckt.nds

def fon(t):
    if t<1e-6:
        return True
    else:
        return False

us=Usrc(ckt,n1,ng,lambda t:5)
sw=Swt(ckt,nb1,ng,fon)
rb1=R(ckt,n1,nb1,1000)
rb2=R(ckt,n1,nb2,1000)
rc1=R(ckt,n1,nc1,300)
rc2=R(ckt,n1,nc2,300)
c1=Cap(ckt,nc2,nb1,1e-7)
c2=Cap(ckt,nc1,nb2,1e-7)
q1=BJT_npn(ckt,nb1,nc1,ng)
q2=BJT_npn(ckt,nb2,nc2,ng)
'''this 2 capacitors must be added, otherwise the sudden flip will break down the solving algorithm'''
cbe1=Cap(ckt,nb1,ng,1e-6)
cbe2=Cap(ckt,nb2,ng,1e-6)
#cbc1=Cap(ckt,nb1,nc1,1e-9)
#cbc2=Cap(ckt,nb2,nc2,1e-9)
#rq1=R(ckt,nb1,ng,1e4)
#rq2=R(ckt,nb2,ng,1e4)


ckt.add_cpns([rb1,rb2,rc1,rc2,c1,c2,q1,q2,us,sw,cbe1,cbe2])
ckt.t_analyse(1e-7,10000)

'''
ckt=Cir('Bistable MultiVib')
ckt.add_nd_lst(['1','nc1','nc2'])
ng,n1,nc1,nc2=ckt.nds

us=Usrc(ckt,n1,ng,lambda t:5)
def f(t):
    if t<1e-5:
        return 1
    else:
        return 0
ut=Usrc(ckt,nc1,ng,f)
rb1=R(ckt,n1,nc2,1000)
rb2=R(ckt,n1,nc1,1000)
rc1=R(ckt,n1,nc1,1000)
rc2=R(ckt,n1,nc2,1000)
q1=BJT_npn(ckt,nc2,nc1,ng)
q2=BJT_npn(ckt,nc1,nc2,ng)

nc1.u0=0.5

ckt.add_cpns([rb1,rb2,rc1,rc2,q1,q2,us,ut])
ckt.t_analyse(1e-6,1000)
'''
'''
ckt=Cir('delay swt')
ckt.add_nd_lst(['1','2'])
ng,n1,n2=ckt.nds

def fon(t):
    if t>1e-3:
        return True
    else:
        return False

us=Usrc(ckt,n1,ng,lambda t:5)
r=R(ckt,n1,n2,5)
sw=Swt(ckt,n2,ng,fon)

ckt.add_cpns([us,r,sw])

ckt.t_analyse(1e-4,100)
'''
