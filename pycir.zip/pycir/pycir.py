import scipy as sp
import numpy as np
import scipy.optimize as opt
import matplotlib.pyplot as plt
from math import *
from cp_simp import *
from cp_blk import *
from cp_trans import *
from cp_logic import *

class Node:
    def __init__(self,cir,idx,name='',u0=0.):
        self.cir=cir
        self.idx=idx
        self.name=name
        self.u=[]
        self.uid=-1
        self.u0=u0
    def on_init(self):
        self.uid,=self.cir.set_vars([self.u0])

    def on_begin(self):
        self.uid,=self.cir.set_vars([self.u0])

    def update(self):
        self.u.append(self.cir.get_res(self.uid))
    

class Branch:
    def __init__(self,nd,out=False):
        self.nd=nd
        self.out=out
        self.i=None
        self.jec_i=None

class Cir:
    def __init__(self,name=''):
        self.nds=[Node(self,0,'gnd')]
        self.cpns=[]
        self.name=name

        self.var_setting =False
        self.var0s=[]
        self.ext_eqs=[]
        self.proc='build'
        self.dt=-1
        self.ts=[]
        self.vars=[]
        '''value of vars in current solving proc, without var0!!!'''
        self.rs=[]
        '''rs without var0!!!'''
        
    def add_nd_lst(self,lst):
        '''add nodes to the circuit, except node0(gnd)
        lst: a list of node names
        return a list of nodes'''
        ret=[]
        for n in lst:
            self.add_node(Node(self,len(self.nds),n))
            ret.append(self.nds[-1])
        return ret
    
    def add_node(self,nd):
        self.nds.append(nd)

    def add_cpns(self,lst):
        '''add components to circuit
        return a list of indexes (the index for main component when it is a multi-cpn)'''
        ret=[]
        for cp in lst:
            if cp.info=='single':
                ret.append(len(self.cpns))
                self.cpns.append(cp)
            elif cp.info=='multi':
                self.cpns+=cp.get_sub_cpns()
                ret.append(len(self.cpns))
                self.cpns.append(cp)
        return ret

    def set_vars(self,y0s):
        '''return a list of indexes (0,1,...)'''
        if self.var_setting:
            ret=[]
            for v in y0s:
                ret.append(len(self.var0s))
                self.var0s.append(v)
            return ret
                
        else:
            assert('inlegal var setting!!!')

    def set_ext_eq(self,f,fprime):
        '''f(vars)=0,fprime->jec'''
        self.ext_eqs.append((f,fprime))
        
    def get_var(self,idx):
        if idx==0:
            return 0
        else:
            return self.vars[idx-1]
        
    def get_res(self,idx):
        if idx==0:
            return 0
        else:
            return self.rs[idx-1]

    def f_eqs(self,vs):
        self.vars=vs
        eqs=[0. for i in self.nds]
        '''kcl eqs'''
        for cp in self.cpns:
            brs=cp.get_branch()
            for b in brs:
                if b.out==False:
                    eqs[b.nd.idx]+=b.i()
                else :
                    eqs[b.nd.idx]-=b.i()
        '''extended eqs'''
        for ex in self.ext_eqs:
            eqs.append(ex[0]())
            
        return eqs[1:]

    def jec_eqs(self,vs):
        self.vars=vs
        n_eq=len(self.nds)-1+len(self.ext_eqs)
        mat_j=np.zeros((n_eq,len(vs)),dtype=np.double)
        '''kcl'''
        for cp in self.cpns:
            brs=cp.get_branch()
            for b in brs:
                if b.nd.idx==0:
                    continue
                cs=b.jec_i()
                if b.out==False:
                    for i,coe in cs:
                        if i==0:
                            continue
                        mat_j[b.nd.idx-1][i-1]+=coe
                else:
                    for i,coe in cs:
                        if i==0:
                            continue
                        mat_j[b.nd.idx-1][i-1]-=coe
        
        '''extended eqs'''
        cur=len(self.nds)-1
        for eq,jeq in self.ext_eqs:
            cs=jeq()
            for i,coe in cs:
                if i==0:
                    continue
                mat_j[cur][i-1]=coe
            cur+=1
        return mat_j

    def flush_vars_eqs(self):
        '''flush all vars and ext_eqs'''
        self.var0s=[]
        self.ext_eqs=[]

    def update_all(self):
        for nd in self.nds:
            nd.update()
        for cp in self.cpns:
            cp.update()
            
    def init_analyse(self):
        self.nvars=0
        self.proc='init_var_setting'
        self.ts=[0]
        self.var_setting=True
        
        self.flush_vars_eqs()
        for nd in self.nds:
            nd.on_init()
        for cp in self.cpns:
            cp.on_init()
        self.var_setting=False
        self.proc='init_analysing'
        self.rs=opt.fsolve(self.f_eqs,self.var0s[1:],fprime=self.jec_eqs)
        self.proc='done_init'
        self.update_all()
        
            
    def t_analyse(self,dt,nstp):
        '''fix:
        when facing stiff problems, the fsolve may give out warnings for bad improvement,
        (because fsolve uses Newton method), and cause unstability in the result.
        We may solve this problem by adopting other non_linear solving approaches (like bineary search?)
        '''
        self.dt=dt
        self.init_analyse()
        self.flush_vars_eqs()
        
        self.proc='sim_var_setting'
        self.var_setting=True
        for nd in self.nds:
            nd.on_begin()
        for cp in self.cpns:
            cp.on_begin()
        self.var_setting=False
        
        self.rs=self.var0s[1:]
        for i in range(nstp):
            self.ts.append(self.dt*(i+1))
            self.proc='t_analysing'
            self.rs=opt.fsolve(self.f_eqs,self.rs,fprime=self.jec_eqs)
            self.proc='done_tstep'
            self.update_all()
