from pycir import *
ckt=Cir()
ckt.add_nd_lst(['1','2','3','4','5'])
ng,n1,n2,n3,n4,n5=ckt.nds

a1=Not(ckt,n1,n2)
a2=Not(ckt,n3,n4)
c1=Cap(ckt,n2,n3,1e-6,1)
c2=Cap(ckt,n4,n1,1e-6,0)
us=Usrc(ckt,n5,ng,lambda t:5)
r1=R(ckt,n5,n1,1000)
r2=R(ckt,n5,n3,1000)
r3=R(ckt,n1,ng,600)
r4=R(ckt,n3,ng,330)
ckt.add_cpns([a1,a2,c1,c2,us,r1,r2,r3,r4])
ckt.t_analyse(1e-6,10000)
plt.plot(ckt.ts,n1.u)
plt.plot(ckt.ts,n3.u)
plt.show()
