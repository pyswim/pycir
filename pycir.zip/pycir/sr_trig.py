from pycir import *
ckt=Cir()
ckt.add_nd_lst(['1','2','3','4'])

def fu(t):
    if t<1e-3:
        return 0
    else:
        return 1
ng,n1,n2,n3,n4=ckt.nds
na1=Nand(ckt,n1,n4,n3)
na2=Nand(ckt,n3,n2,n4)
in1=Usrc(ckt,n1,ng,lambda t:5)
in2=Usrc(ckt,n2,ng,fu)
ckt.add_cpns([na1,na2,in1,in2])
ckt.t_analyse(1e-4,10000)
