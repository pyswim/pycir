from math import *

class BJT_npn:
    def __init__(self,cir,nb,nc,ne,af=0.996,ar=0.96):
        '''NOTICE: you need to choose appropriate init val for node voltage'''
        self.cir=cir
        self.info='multi'
        self.nb=nb
        self.nc=nc
        self.ne=ne
        self.nb.u0=0.1
        self.nc.u0=0.1
        self.ne.u0=0.1
        self.af=af
        self.ar=ar
        from pycir import Branch
        from cp_simp import Diode
        from cp_blk import Acas
        self.dbc=Diode(self.cir,self.nb,self.nc)
        self.dbc.isat=1e-16
        self.dbe=Diode(self.cir,self.nb,self.ne)
        self.dbe.isat=1e-16
        self.iscb=Acas(self.cir,self.nb,self.nc,self.dbe.br2,lambda i:self.af*i,lambda i:self.af)
        self.iseb=Acas(self.cir,self.ne,self.nb,self.dbc.br2,lambda i:self.ar*i,lambda i:self.ar)

        self.ib=[]
        self.ic=[]
        self.ie=[]

    def get_sub_cpns(self):
        return self.dbc,self.dbe,self.iscb,self.iseb

    def on_init(self):
        self.ib=[]
        self.ic=[]
        self.ie=[]
    def on_begin(self):
        pass
    def update(self):
        self.ib.append((1-self.ar)*self.dbc.i[-1]+(1-self.af)*self.dbe.i[-1])
        self.ic.append(self.af*self.dbe.i[-1]-self.dbc.i[-1])
        self.ie.append(self.ar*self.dbc.i[-1]-self.dbe.i[-1])
    def get_branch(self):
        return []
    
