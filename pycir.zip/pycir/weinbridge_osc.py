from pycir import *
from math import *

ckt=Cir()
ckt.add_nd_lst(['1','2','3'])
ng,n1,n2,n3=ckt.nds

def s(x):
    return 1/(1+exp(-x))
def ds(x):
    return s(x)*(1-s(x))
def fctl(u):
    return 10*s(u)-5
def dfctl(u):
    return 10*ds(u)
opamp=Vcvs(ckt,n1,n2,n3,ng,fctl,dfctl)

r1=R(ckt,n2,ng,100)
r2=R(ckt,n3,n2,1000)
r3=R(ckt,n1,ng,100)
c1=Cap(ckt,n1,ng,10e-6,u0=0)
c2=Cap(ckt,n3,n1,10e-6,u0=0.1)

ckt.add_cpns([r1,r2,r3,c1,c2,opamp])
ckt.t_analyse(1e-6,100000)
