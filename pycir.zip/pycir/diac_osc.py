from pycir import *

ckt=Cir('diac')

ckt.add_nd_lst(['n1','n2','n3'])

ng,n1,n2,n3=ckt.nds

def f(x):
    return x/(x**2+2)

def df(x):
    return ((x**2+2)-2*x*x)/(x**2+2)**2


us=Usrc(ckt,n1,ng,lambda t:1000)
r1=R(ckt,n1,n2,10)
r2=R(ckt,n3,ng,10)
c=Cap(ckt,n2,ng,10e-6)
d=Acv_2p(ckt,n3,ng,f,df)
ckt.add_cpns([us,r1,r2,c,d])

ckt.t_analyse(1e-5,100000)


'''
us=Usrc(ckt,n1,ng,lambda t:50*sin(100*pi*t))
d=Acv_2p(ckt,n2,ng,f,df)
r=R(ckt,n1,n2,100)
ckt.add_cpns([us,d,r])

ckt.t_analyse(1e-5,100000)
'''

