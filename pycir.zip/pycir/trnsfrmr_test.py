from pycir import *

ckt=Cir('transformer')

'''
ckt.add_nd_lst(['n1','n2'])

ng,n1,n2=ckt.nds

us=Usrc(ckt,n1,ng,lambda t:5*sin(1000*pi*t))
r=R(ckt,n2,ng,1000)
tr=Trnsfrmr2(ckt,n1,ng,n2,ng,0.1,0.4,0.199,0,0)
ckt.add_cpns([us,r,tr])

ckt.t_analyse(1e-5,10000)

'''

ckt.add_nd_lst(['n1','n2','n3','n4','n5'])
ng,n1,n2,n3,n4,n5=ckt.nds
us=Usrc(ckt,n1,ng,lambda t:5)
bjt=BJT_npn(ckt,n4,n2,ng)
tr=Trnsfrmr2(ckt,n1,ng,n5,ng,1e-3,0.1,0.0019,0,0)
c=Cap(ckt,n3,ng,1e-6)
r1=R(ckt,n1,n2,3000)
r2=R(ckt,n5,n3,0.5)
r3=R(ckt,n3,n4,5000)
r4=R(ckt,n1,n4,4000)
ckt.add_cpns([us,bjt,tr,c,r1,r2,r3,r4])

ckt.t_analyse(1e-5,10000)
