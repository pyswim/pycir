from pycir import *

ckt=Cir()
ckt.add_nd_lst(['1','2','3','4','5'])
ng,n1,n2,n3,n4,n5=ckt.nds

nt1=Not(ckt,n1,n2,0.1)
nt2=Not(ckt,n2,n3,0.1)
nt1.slope=1e4
nt2.slope=1e4

r1=R(ckt,n1,n4,10000)
r2=R(ckt,n2,n5,1000)
c=Cap(ckt,n3,n5,10e-6,5)
def fon(t):
    if t<1e-4:
        return False
    else:
        return True
    
sw=Swt(ckt,n4,n5,fon)

ckt.add_cpns([nt1,nt2,r1,r2,c,sw])
ckt.t_analyse(1e-4,10000)

plt.plot(ckt.ts,[i-j for i,j in zip(n5.u,n3.u)])
plt.plot(ckt.ts,n3.u)
